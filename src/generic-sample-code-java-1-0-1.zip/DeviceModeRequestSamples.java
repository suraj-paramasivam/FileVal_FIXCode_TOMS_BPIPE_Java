package com.bloomberg.wag.sdk.samples;

import com.auth0.jwt.JWT;
import com.bloomberg.wag.sdk.RequestClient;
import com.bloomberg.wag.sdk.usermode.AuthenticationException;
import com.bloomberg.wag.sdk.usermode.DeviceModeFlow;
import org.glassfish.jersey.media.sse.EventInput;
import org.glassfish.jersey.media.sse.InboundEvent;

import javax.ws.rs.sse.SseEventSource;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class DeviceModeRequestSamples {
    /**
     * Insert your client ID
     */
    private static final String CLIENT_ID = "";

    /**
     * Insert your secret
     */
    private static final String SECRET = "";

    /**
     * Insert accessing scopes
     */
    private static final List<String> SCOPES = null;


    public static void main(String[] args) throws IOException, AuthenticationException, InterruptedException {
        final DeviceModeFlow flow = new DeviceModeFlow(
                "https://api.blpprofessional.com",
                60 * 1000,
                CLIENT_ID,
                SECRET,
                SCOPES
        );

        // Get url for user to login
        final String loginUrl = flow.authenticate();

        System.out.println(loginUrl);
        System.out.println("Hit enter after log-in...");
        //noinspection ResultOfMethodCallIgnored
        System.in.read();

        // Fetch required tokens after logged in
        flow.fetchTokens();

        // Get the RequestClient with user information
        RequestClient client = flow.getRequestClient();

        // GET request with query parameters
        HttpURLConnection response = client.getRequestBuilder("GET", "/sandbox/v1/user-mode/echo")
                .withQueryParam("input", "Hello World!")
                .doRequest();
        print(response);

        // POST request with JSON body
        response = client.getRequestBuilder("POST", "/sandbox/v1/user-mode/echo")
                .withBody("{\"input\":\"Hello World!\"}")
                .withHeader("Content-Type", "application/json")
                .doRequest();

        print(response);

        // Request with custom JWT claim
        response = client.getRequestBuilder("GET", "/sandbox/v1/user-mode/ping")
                .withCustomJwtBuilder(JWT.create()
                        .withClaim("name", "value"))
                .doRequest();
        print(response);

        //GET request to subscribe to SSE
        EventInput eventInput = client.getSseBuilder("/sandbox/v1/server-mode/stream")
                .withQueryParam("input", "Hello World!")
                .doSubscribe();

        while (!eventInput.isClosed()) {
            final InboundEvent inboundEvent = eventInput.read();
            if (inboundEvent == null) {
                // connection has been closed
                break;
            }
            System.out.println(inboundEvent);
        }

        // Refresh tokens if they'are expired. If refreshToken is also expire, user need to login again
        flow.refreshTokens();

        // Need to get a new client after any token update
        client = flow.getRequestClient();

        // Request with custom JWT claim
        response = client.getRequestBuilder("GET", "/sandbox/v1/user-mode/ping")
                .withCustomJwtBuilder(JWT.create()
                        .withClaim("name", "value"))
                .doRequest();

        print(response);
    }

    private static void print(HttpURLConnection response) throws IOException {
        System.out.println(response.getRequestMethod() + " " + response.getURL());

        System.out.println("Response:");

        System.out.println(response.getHeaderFields());

        try (Scanner scanner = new Scanner(response.getInputStream())) {
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
        } catch (Exception e) {
            Scanner scanner = new Scanner(response.getErrorStream());
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
        }

        System.out.println();
    }
}
