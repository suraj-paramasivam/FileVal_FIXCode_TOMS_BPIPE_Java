package com.bloomberg.wag.sdk.samples;

import com.auth0.jwt.JWT;
import com.bloomberg.wag.sdk.RequestClient;
import com.bloomberg.wag.sdk.usermode.AuthenticationException;
import com.bloomberg.wag.sdk.usermode.HybridModeFlow;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import static spark.Spark.*;

/**
 * This sample is a Hybrid Mode Sample that running as a web service with java Spark.
 * It wraps sandbox APIs in endpoints:
 * /login:          for user to login
 * /refresh:        refresh tokens
 * /finish_login:   the redirect uri for the service to fetch tokens
 * /echo:           GET and POST endpoints. Forward request to sandbox
 * /ping:           GET endpoint. Forward request to sandbox
 */
public class HybridModeRequestSamples {
    /**
     * Insert your client ID
     */
    private static final String CLIENT_ID = "";

    /**
     * Insert your secret
     */
    private static final String SECRET = "";


    /**
     * Insert accessing scopes
     */
    private static final List<String> SCOPES = null;

    /**
     * Insert your redirect URL
     * This is the redirect URL after login completed
     * a `code` will be in the query params for fetching
     * access tokens
     */
    private static final String REDIRECT_URI = "";

    public static void main(String[] args) throws IOException, AuthenticationException {
        final HybridModeFlow flow = new HybridModeFlow(
                "https://api.blpprofessional.com",
                60 * 1000,
                CLIENT_ID,
                SECRET,
                SCOPES,
                REDIRECT_URI
        );

        port(9000);

        // A Spark endpoint for logging in
        get("/login", (req, res) -> {
            return flow.getAuthenticateHtml("");
        });

        // A Spark endpoint for handling redirect after login
        get("/finish_login", (req, res) -> {
            flow.fetchTokens(req.queryParams("code"));
            return flow.getTokens();
        });

        get("/echo", (req, res) -> {
            final RequestClient client = flow.getRequestClient();
            // GET request with query parameters
            HttpURLConnection response = client.getRequestBuilder("GET", "/sandbox/v1/user-mode/echo")
                    .withQueryParam("input", "Hello World!")
                    .doRequest();

            return getResponse(response);
        });

        post("/echo", (req, res) -> {
            final RequestClient client = flow.getRequestClient();
            // POST request with JSON body
            HttpURLConnection response = client.getRequestBuilder("POST", "/sandbox/v1/user-mode/echo")
                    .withBody("{\"input\":\"Hello World!\"}")
                    .withHeader("Content-Type", "application/json")
                    .doRequest();

            return getResponse(response);
        });

        get("/ping", (req, res) -> {
            final RequestClient client = flow.getRequestClient();
            // Request with custom JWT claim
            HttpURLConnection response = client.getRequestBuilder("GET", "/sandbox/v1/user-mode/ping")
                    .withCustomJwtBuilder(JWT.create()
                            .withClaim("name", "value"))
                    .doRequest();

            return getResponse(response);

        });

        get("/refresh", (req, res) -> {
            final StringBuilder content = new StringBuilder();
            content.append("old_tokens:")
                    .append(flow.getTokens())
                    .append(System.getProperty("line.separator"));

            // Refresh tokens if they'are expired.
            // If refreshToken is also expire, user need to login again
            flow.refreshTokens();
            content.append("new_tokens:")
                    .append(flow.getTokens())
                    .append(System.getProperty("line.separator"));

            return content.toString();
        });

    }

    private static String getResponse(HttpURLConnection response) throws IOException {
        StringBuilder sb = new StringBuilder();

        sb.append(response.getRequestMethod())
                .append(" ")
                .append(response.getURL());

        sb.append("Response:");

        sb.append(response.getHeaderFields());

        try (Scanner scanner = new Scanner(response.getInputStream())) {
            while (scanner.hasNextLine()) {
                sb.append(scanner.nextLine());
            }
        }
        return sb.toString();
    }
}
