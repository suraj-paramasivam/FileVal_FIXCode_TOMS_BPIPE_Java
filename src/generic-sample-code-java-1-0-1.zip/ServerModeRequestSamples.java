package com.bloomberg.wag.sdk.samples;

import com.auth0.jwt.JWT;
import com.bloomberg.wag.sdk.RequestClient;
import com.bloomberg.wag.sdk.servermode.ServerModeClient;
import org.glassfish.jersey.media.sse.EventInput;
import org.glassfish.jersey.media.sse.InboundEvent;

import javax.ws.rs.sse.SseEventSource;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.Scanner;

public class ServerModeRequestSamples {

  /**
   * Insert your client ID
   */
  private static final String CLIENT_ID = "";

  /**
   * Insert your secret
   */
  private static final String SECRET = "";

  public static void main(String[] args) throws IOException, InterruptedException {
    RequestClient client = new ServerModeClient(
        "https://api.blpprofessional.com",
        60 * 1000,
        CLIENT_ID,
        SECRET
    );

    //GET request with query parameters
    HttpURLConnection response = client.getRequestBuilder("GET", "/sandbox/v1/server-mode/echo")
        .withQueryParam("input", "Hello World!")
        .doRequest();

    print(response);

    //POST request with JSON body
    response = client.getRequestBuilder("POST", "/sandbox/v1/server-mode/echo")
        .withBody("{\"input\":\"Hello World!\"}")
        .withHeader("Content-Type", "application/json")
        .doRequest();

    print(response);

    //Request with custom JWT claim
    response = client.getRequestBuilder("GET", "/sandbox/v1/server-mode/ping")
        .withCustomJwtBuilder(JWT.create()
            .withClaim("name", "value"))
        .doRequest();

    print(response);

    //GET request to subscribe to SSE
    EventInput eventInput = client.getSseBuilder("/sandbox/v1/server-mode/stream")
            .withQueryParam("input", "Hello World!")
            .doSubscribe();

    while (!eventInput.isClosed()) {
      final InboundEvent inboundEvent = eventInput.read();
      if (inboundEvent == null) {
        // connection has been closed
        break;
      }
      System.out.println(inboundEvent);
    }
  }

  private static void print(HttpURLConnection response) throws IOException {
    System.out.println(response.getRequestMethod() + " " + response.getURL());

    System.out.println("Response:");

    System.out.println(response.getHeaderFields());

    try (Scanner scanner = new Scanner(response.getInputStream())) {
      while (scanner.hasNextLine()) {
        System.out.println(scanner.nextLine());
      }
    }

    System.out.println();
  }
}
